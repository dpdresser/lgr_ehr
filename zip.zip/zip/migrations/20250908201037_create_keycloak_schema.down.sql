-- Drop keycloak schema and all its contents
-- This will remove all Keycloak tables, sequences, and functions
DROP SCHEMA IF EXISTS keycloak CASCADE;
